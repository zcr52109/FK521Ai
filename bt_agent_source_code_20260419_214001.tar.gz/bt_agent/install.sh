#!/bin/bash

bt_agnet_plugin_dir=/www/server/panel/plugin/bt_agent

InstallBTAGENT(){
    cd $bt_agnet_plugin_dir
    btpip install openai numpy

        #百炼平台埋点
    if [ "$(cat /www/server/panel/data/o.pl)" == "aliyun_latest" ];then
        product_id=$(curl -s http://100.100.100.200/latest/meta-data/image/market-place/product-code)
        if [ "$product_id" != "" ] && [ -z "$(echo "$product_id" | grep "404 - Not Found")" ];then
            account_id=$(curl -s http://100.100.100.200/latest/meta-data/owner-account-id)
            echo $product_id > $bt_agnet_plugin_dir/aliyun_product_id.pl
            echo $account_id > $bt_agnet_plugin_dir/aliyun_account_id.pl
        fi
    fi

    btpython init_knowledge.py
}

UninstallBTAGENT(){
    rm -rf $bt_agnet_plugin_dir
}

action=${1}
if [ "${1}" == 'install' ];then
   InstallBTAGENT
else
   UninstallBTAGENT
fi

echo 'True' >/www/server/panel/data/restart.pl