# coding: utf-8
import sys
import os

# Ensure plugin path is in sys.path
panelPath = os.getenv('BT_PANEL')
if not panelPath: panelPath = '/www/server/panel'
plugin_path = '{}/plugin/bt_agent'.format(panelPath)
if plugin_path not in sys.path:
    sys.path.append(plugin_path)

from bt_agent_main import bt_agent_main

def init_knowledge_base():
    print("Initializing Knowledge Base...")
    
    knowledges = [
        {
            "topic": "system_directory_structure", 
            "text": """# 宝塔面板核心目录结构
#### 面板根目录：/www

1. 核心功能类目录
   - .Recycle_bin：回收站（文件恢复场景核心）
   - cosfs：云存储目录（按厂商划分：alioss/阿里云、bos/百度云、obs/华为云）
   - wwwlogs：日志核心目录（关键文件：域名.log（网站访问）、域名.error.log（网站错误）、nginx_error.log（Nginx错误）、access.log）
   - wwwroot：网站根目录（所有站点文件的核心存放位置）
   - Backup：备份目录（核心分类：database/数据库备份、File_history/文件历史备份、panel/面板备份、site/网站备份、olddate/数据库目录备份）

2. 程序运行类目录（Server）
   - Panel（面板主程序核心）：
     - BTPanel：面板核心代码目录
       - __pycache__：Python字节码缓存（提升模块导入速度）
       - static/templates：前端静态资源/HTML模板
       - __init__.py：基于Flask的面板Web服务入口（路由/权限/请求处理核心）
     - data：面板核心数据目录（关键文件：default.db（面板数据库）、port.pl（面板端口）、userInfo.json（用户绑定信息）、admin_path.pl（安全入口）、ipv6.pl（IPv6监听））
     - 高频关联子目录：cache（缓存）、plugin（插件）、vhost（站点配置）、logs（面板日志）、pyenv（运行环境）

### 总结
1. AI助手需重点关注/www下的**日志（wwwlogs）、备份（Backup）、站点文件（wwwroot）、面板程序（Server/Panel）** 四大核心目录；
2. Server/Panel/data下的default.db、port.pl等是面板配置关键文件，BTPanel/__init__.py是面板核心运行入口；
3. 云存储（cosfs）、回收站（.Recycle_bin）是文件管理类问题的核心关联目录。"""
        },
        {
            "topic": "bt_cli_commands", 
            "text": """# 宝塔面板相关命令（使用后部分命令将进入交互式）
宝塔面板核心bt命令（精简版，含执行方式）

一、服务控制（核心高频）
`bt 1` 重启面板服务
`bt 2` 停止面板服务
`bt 3` 启动面板服务
`bt 4` 重载面板服务

二、账号&安全（常用操作）
`bt 5` 修改面板密码
`bt 6` 修改面板用户名
`bt 7` 强制修改MySQL密码
`bt 28` 修改面板安全入口

三、配置&维护（面板管理）
`bt 8` 修改面板端口
`bt 9` 清除面板缓存
`bt 14` 查看面板登录信息、安全入口访问信息
`bt 15` 清理系统垃圾
`bt 16` 修复面板（安装当前版本最新bug修复包）
`bt 34` 更新面板（更新到最新版本）
`bt 22` 显示面板错误日志"""
        }
    ]
    
    try:
        bt_agent = bt_agent_main()
        for item in knowledges:
            print(f"初始化知识库: {item['topic']}")
            response = bt_agent.add_global_knowledge(item)
            print(f"执行结果: {response}")
            
        print("知识库初始化完成.")
    except Exception as e:
        print(f"知识库初始化错误: {e}")

if __name__ == '__main__':
    #删除目录
    import shutil
    import os
    knowledge_dir = '/www/server/panel/plugin/bt_agent/global_knowledge'
    if os.path.exists(knowledge_dir):
        shutil.rmtree(knowledge_dir)
        print(f"已删除目录: {knowledge_dir}")
    init_knowledge_base()
