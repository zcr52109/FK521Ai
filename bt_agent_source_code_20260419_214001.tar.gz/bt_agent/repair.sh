#!/bin/bash
bt_agnet_plugin_dir=/www/server/panel/plugin/bt_agent
#chmod +x $agent_plugin_dir/bt_agent

btpip install openai numpy --upgrade

cd $bt_agnet_plugin_dir
btpython init_knowledge.py